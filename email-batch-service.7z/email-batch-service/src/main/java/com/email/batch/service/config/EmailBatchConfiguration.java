package com.email.batch.service.config;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.email.batch.service.publisher.RabitMQPublisher;
import com.email.request.handling.model.EmailRequest;

@Configuration
@EnableBatchProcessing
@EnableScheduling
@EnableAsync
public class EmailBatchConfiguration {
	
	@Autowired
	public JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	
	
	  @Autowired 
	  public DataSource dataSource;
	
	@Bean
	public DataSource dataSource() {
		
		final DriverManagerDataSource dataSource= new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost/emailaddressbatch");
		dataSource.setUsername("root");
		dataSource.setPassword("Happy@700");
		return dataSource;
	}

	@Bean
	public JdbcCursorItemReader<EmailRequest> reader(){
		JdbcCursorItemReader<EmailRequest> reader= new JdbcCursorItemReader<>();
		reader.setDataSource(dataSource);
		reader.setSql("SELECT email FROM emailaddressbatch.user");
		reader.setRowMapper(new UserRowMapper());
		
		return reader;
	}
	
	public class UserRowMapper implements RowMapper<EmailRequest> {

		@Override
		public EmailRequest mapRow(ResultSet rs, int rowNum) throws SQLException {
			EmailRequest user = new EmailRequest();
			user.setEmail(rs.getString("email"));
			return user;
		}

	}
	
	
	public EmailRequestItemProcesser processer() {
		return new EmailRequestItemProcesser();
	}
	
	@Bean
	public RabitMQPublisher publishToQueue() {
		return new RabitMQPublisher();
	}

	@Bean
	@Scheduled(fixedRate = 1000)
	public Step step1() {
		
		return stepBuilderFactory.get("step1").<EmailRequest,EmailRequest> chunk(1)
				.reader(reader())
				.processor(processer())
				.writer(publishToQueue())
				.build();
	}
	@Bean
	public Job exportUserJob() {
		return jobBuilderFactory.get("exportUserJob")
				.incrementer(new RunIdIncrementer())
				.start(step1())
				.build();
		
		
	}
	
}
