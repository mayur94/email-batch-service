package com.email.batch.service.config;

import org.springframework.batch.item.ItemProcessor;

import com.email.request.handling.model.EmailRequest;


public class EmailRequestItemProcesser implements ItemProcessor<EmailRequest, EmailRequest> {
	
	
	
	@Override
	public EmailRequest process(EmailRequest user) throws Exception {

		return user;
	}

}
