package com.email.batch.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailBatchServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmailBatchServiceApplication.class, args);
	}

}
